-- 1. Top five areas by unique patient count
SELECT area, COUNT(DISTINCT patient_id) AS patient_count
FROM appointments
GROUP BY area
ORDER BY patient_count DESC
LIMIT 5;

-- 2. Monthly collected revenue (paid payments only)
SELECT substr(payment_date, 1, 7) AS month,
       SUM(amount_inr) AS revenue_inr
FROM payments
WHERE payment_status = 'Paid'
GROUP BY month
ORDER BY month;

-- 3. Appointment cancellation percentage
SELECT
  ROUND(100.0 * SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END)
        / NULLIF(COUNT(*), 0), 2) AS cancellation_pct
FROM appointments;

-- 4. Repeat patients (patients with 2+ completed appointments)
SELECT COUNT(*) AS repeat_patient_count
FROM (
  SELECT patient_id
  FROM appointments
  WHERE status = 'Completed'
  GROUP BY patient_id
  HAVING COUNT(*) >= 2
);

-- 5. Most popular treatment
SELECT treatment_type, COUNT(*) AS completed_sessions
FROM appointments
WHERE status = 'Completed'
GROUP BY treatment_type
ORDER BY completed_sessions DESC
LIMIT 1;

-- 6. Therapist completed sessions
SELECT t.therapist_name, COUNT(*) AS completed_sessions
FROM appointments a
JOIN therapists t ON a.therapist_id = t.therapist_id
WHERE a.status = 'Completed'
GROUP BY t.therapist_id, t.therapist_name
ORDER BY completed_sessions DESC;

-- 7. High-demand areas with no center in the same area.
-- In this sample, every area maps to a center for demonstration.
SELECT a.area, COUNT(DISTINCT a.patient_id) AS patient_count
FROM appointments a
LEFT JOIN centers c ON a.area = c.area
WHERE c.center_id IS NULL
GROUP BY a.area
ORDER BY patient_count DESC;

-- 8. Patients with no completed appointment in the last 30 days
-- The date is relative to the latest date in the sample, not today's date.
WITH latest AS (SELECT MAX(appointment_date) AS max_date FROM appointments)
SELECT p.patient_id, p.area
FROM patients p
CROSS JOIN latest l
WHERE NOT EXISTS (
  SELECT 1
  FROM appointments a
  WHERE a.patient_id = p.patient_id
    AND a.status = 'Completed'
    AND a.appointment_date >= date(l.max_date, '-30 day')
);

-- 9. Center-wise paid revenue
SELECT c.center_name, SUM(p.amount_inr) AS revenue_inr
FROM payments p
JOIN appointments a ON p.appointment_id = a.appointment_id
JOIN centers c ON a.center_id = c.center_id
WHERE p.payment_status = 'Paid'
GROUP BY c.center_id, c.center_name
ORDER BY revenue_inr DESC;
