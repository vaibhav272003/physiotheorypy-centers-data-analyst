-- Physiotherapy Business Intelligence: SQLite schema
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS patients (
  patient_id TEXT PRIMARY KEY,
  age INTEGER,
  gender TEXT,
  area TEXT,
  city TEXT,
  registration_date TEXT
);

CREATE TABLE IF NOT EXISTS centers (
  center_id TEXT PRIMARY KEY,
  center_name TEXT,
  area TEXT,
  city TEXT
);

CREATE TABLE IF NOT EXISTS therapists (
  therapist_id TEXT PRIMARY KEY,
  therapist_name TEXT,
  specialization TEXT
);

CREATE TABLE IF NOT EXISTS appointments (
  appointment_id TEXT PRIMARY KEY,
  patient_id TEXT,
  appointment_date TEXT,
  status TEXT,
  treatment_type TEXT,
  therapist_id TEXT,
  session_number INTEGER,
  area TEXT,
  center_id TEXT,
  FOREIGN KEY(patient_id) REFERENCES patients(patient_id),
  FOREIGN KEY(therapist_id) REFERENCES therapists(therapist_id),
  FOREIGN KEY(center_id) REFERENCES centers(center_id)
);

CREATE TABLE IF NOT EXISTS payments (
  payment_id TEXT PRIMARY KEY,
  appointment_id TEXT,
  patient_id TEXT,
  payment_date TEXT,
  amount_inr REAL,
  payment_mode TEXT,
  payment_status TEXT,
  FOREIGN KEY(appointment_id) REFERENCES appointments(appointment_id),
  FOREIGN KEY(patient_id) REFERENCES patients(patient_id)
);

CREATE TABLE IF NOT EXISTS treatments (
  treatment_id TEXT PRIMARY KEY,
  appointment_id TEXT,
  patient_id TEXT,
  treatment_type TEXT,
  therapist_id TEXT,
  FOREIGN KEY(appointment_id) REFERENCES appointments(appointment_id),
  FOREIGN KEY(patient_id) REFERENCES patients(patient_id),
  FOREIGN KEY(therapist_id) REFERENCES therapists(therapist_id)
);
