from pathlib import Path
import sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "physiotherapy_analytics.db"
DATA = ROOT / "data"

def main():
    if DB_PATH.exists():
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)
    conn.executescript((ROOT / "sql" / "schema.sql").read_text(encoding="utf-8"))
    for table in ["patients", "centers", "therapists", "appointments", "payments", "treatments"]:
        df = pd.read_csv(DATA / f"{table}.csv")
        df.to_sql(table, conn, if_exists="append", index=False)
    conn.commit()
    print(f"Database created: {DB_PATH}")
    for table in ["patients", "appointments", "payments"]:
        count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"{table}: {count:,} rows")
    conn.close()

if __name__ == "__main__":
    main()
