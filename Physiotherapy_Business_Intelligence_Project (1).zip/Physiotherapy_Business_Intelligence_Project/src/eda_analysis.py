from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

patients = pd.read_csv(DATA / "patients.csv")
appointments = pd.read_csv(DATA / "appointments.csv", parse_dates=["appointment_date"])
payments = pd.read_csv(DATA / "payments.csv", parse_dates=["payment_date"])

# Basic data-quality checks
print("Patients shape:", patients.shape)
print("Appointments shape:", appointments.shape)
print("Duplicate patient IDs:", patients["patient_id"].duplicated().sum())
print("Missing values in appointments:\\n", appointments.isna().sum())

# Business KPIs
completed = appointments[appointments["status"] == "Completed"]
repeat_counts = completed.groupby("patient_id").size()
repeat_rate = (repeat_counts.ge(2).sum() / patients["patient_id"].nunique()) * 100
cancel_rate = (appointments["status"].eq("Cancelled").mean()) * 100
paid_revenue = payments.loc[payments["payment_status"] == "Paid", "amount_inr"].sum()

print(f"Completed appointments: {len(completed):,}")
print(f"Cancellation rate: {cancel_rate:.1f}%")
print(f"Repeat patient rate: {repeat_rate:.1f}%")
print(f"Paid revenue: ₹{paid_revenue:,.0f}")

# Monthly revenue chart
monthly = (payments[payments["payment_status"] == "Paid"]
           .assign(month=lambda x: x["payment_date"].dt.to_period("M").astype(str))
           .groupby("month", as_index=False)["amount_inr"].sum())
plt.figure(figsize=(11, 5))
plt.plot(monthly["month"], monthly["amount_inr"], marker="o")
plt.xticks(rotation=60, ha="right")
plt.title("Monthly Paid Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue (INR)")
plt.tight_layout()
plt.savefig(OUT / "monthly_revenue.png", dpi=150)
plt.close()

# Top areas by unique patient count
area_counts = appointments.groupby("area")["patient_id"].nunique().sort_values(ascending=False)
plt.figure(figsize=(10, 5))
area_counts.plot(kind="bar")
plt.title("Unique Patients by Area")
plt.xlabel("Area")
plt.ylabel("Unique patients")
plt.tight_layout()
plt.savefig(OUT / "patients_by_area.png", dpi=150)
plt.close()

print("Charts saved in:", OUT)
