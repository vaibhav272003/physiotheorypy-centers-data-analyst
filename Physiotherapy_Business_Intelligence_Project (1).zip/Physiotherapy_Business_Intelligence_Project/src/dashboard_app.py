from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

st.set_page_config(page_title="Physiotherapy Analytics", page_icon="📊", layout="wide")
st.title("Physiotherapy Business Intelligence Dashboard")
st.caption("Demonstration project using synthetic data. Not real patient records.")

@st.cache_data
def load_data():
    patients = pd.read_csv(DATA / "patients.csv")
    appointments = pd.read_csv(DATA / "appointments.csv", parse_dates=["appointment_date"])
    payments = pd.read_csv(DATA / "payments.csv", parse_dates=["payment_date"])
    centers = pd.read_csv(DATA / "centers.csv")
    therapists = pd.read_csv(DATA / "therapists.csv")
    return patients, appointments, payments, centers, therapists

patients, appointments, payments, centers, therapists = load_data()

st.sidebar.header("Dashboard filters")
areas = ["All"] + sorted(appointments["area"].dropna().unique().tolist())
selected_area = st.sidebar.selectbox("Area", areas)
statuses = sorted(appointments["status"].dropna().unique().tolist())
selected_statuses = st.sidebar.multiselect("Appointment status", statuses, default=statuses)
min_date = appointments["appointment_date"].min().date()
max_date = appointments["appointment_date"].max().date()
date_range = st.sidebar.date_input("Appointment date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)

filtered = appointments.copy()
if selected_area != "All":
    filtered = filtered[filtered["area"] == selected_area]
if selected_statuses:
    filtered = filtered[filtered["status"].isin(selected_statuses)]
if isinstance(date_range, tuple) and len(date_range) == 2:
    filtered = filtered[
        (filtered["appointment_date"].dt.date >= date_range[0]) &
        (filtered["appointment_date"].dt.date <= date_range[1])
    ]

filtered_ids = set(filtered["appointment_id"])
pay = payments[payments["appointment_id"].isin(filtered_ids)]
paid = pay[pay["payment_status"] == "Paid"]
completed = filtered[filtered["status"] == "Completed"]
unique_patients = filtered["patient_id"].nunique()
revenue = paid["amount_inr"].sum()
cancel_rate = (filtered["status"].eq("Cancelled").mean() * 100) if len(filtered) else 0
repeat_patient_count = completed.groupby("patient_id").size().ge(2).sum() if len(completed) else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Unique patients", f"{unique_patients:,}")
c2.metric("Appointments", f"{len(filtered):,}")
c3.metric("Paid revenue", f"₹{revenue:,.0f}")
c4.metric("Cancellation rate", f"{cancel_rate:.1f}%")

left, right = st.columns(2)
with left:
    st.subheader("Appointment trend")
    if len(filtered):
        trend = filtered.assign(month=filtered["appointment_date"].dt.to_period("M").astype(str)).groupby("month").size().reset_index(name="appointments")
        fig = px.line(trend, x="month", y="appointments", markers=True, title="Appointments by month")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No appointments for the selected filters.")
with right:
    st.subheader("Patient demand by area")
    area_data = filtered.groupby("area")["patient_id"].nunique().reset_index(name="unique_patients").sort_values("unique_patients", ascending=False)
    fig = px.bar(area_data, x="area", y="unique_patients", title="Unique patients by area")
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("Appointment status")
    status_data = filtered["status"].value_counts().rename_axis("status").reset_index(name="count")
    if len(status_data):
        st.plotly_chart(px.pie(status_data, names="status", values="count", hole=.45), use_container_width=True)
with right:
    st.subheader("Treatment demand")
    treatment_data = completed["treatment_type"].value_counts().rename_axis("treatment").reset_index(name="completed_sessions")
    st.plotly_chart(px.bar(treatment_data, x="treatment", y="completed_sessions", title="Completed sessions by treatment"), use_container_width=True)

st.subheader("Center performance")
center_view = (filtered.merge(centers[["center_id","center_name"]], on="center_id", how="left")
               .groupby("center_name", dropna=False)
               .agg(appointments=("appointment_id","count"), unique_patients=("patient_id","nunique"))
               .reset_index())
st.dataframe(center_view, use_container_width=True, hide_index=True)

st.subheader("How to interpret this dashboard")
st.markdown("""
- **Unique patients** counts distinct patient IDs in the filtered appointment records.
- **Paid revenue** sums payment rows marked `Paid` that belong to filtered appointments.
- **Cancellation rate** is cancelled appointments divided by all filtered appointments.
- **Patient demand by area** counts distinct patients, not total visits.
- Use these metrics as decision support. Before opening a new center, also evaluate rent, therapist availability, competition, travel time, and actual local population.
""")
