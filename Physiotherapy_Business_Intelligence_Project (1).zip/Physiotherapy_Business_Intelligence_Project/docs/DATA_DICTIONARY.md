# Data dictionary

| File | Grain | Key columns |
|---|---|---|
| patients.csv | One row per patient | patient_id, age, gender, area, registration_date |
| appointments.csv | One row per appointment | appointment_id, patient_id, appointment_date, status, treatment_type, therapist_id, center_id |
| payments.csv | One row per payment | payment_id, appointment_id, amount_inr, payment_status |
| centers.csv | One row per center | center_id, center_name, area |
| therapists.csv | One row per therapist | therapist_id, therapist_name, specialization |
| treatments.csv | One row per treatment/appointment | treatment_id, appointment_id, treatment_type, therapist_id |

All IDs and records are synthetic. `appointment_date` and `payment_date` use YYYY-MM-DD.
