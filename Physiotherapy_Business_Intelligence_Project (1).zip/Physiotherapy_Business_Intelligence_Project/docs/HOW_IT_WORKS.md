# How the project works — simple walkthrough

## Data flow

`CSV data → SQLite database → SQL analysis → Python EDA → Streamlit / Power BI dashboard → business decisions`

## 1. Data layer
- `patients.csv`: one row per sample patient.
- `appointments.csv`: one row per appointment.
- `payments.csv`: payment records for completed appointments.
- `centers.csv`: sample center details.
- `therapists.csv`: sample therapist details.
- `treatments.csv`: treatment associated with each appointment.

The patient ID and appointment ID connect the tables. This is called a relational data model.

## 2. SQL layer
`build_database.py` creates the SQLite tables using `schema.sql` and loads each CSV.
The SQL queries then answer questions such as:
- Which areas have the most unique patients?
- How much paid revenue was recorded each month?
- What percentage of appointments were cancelled?
- Which treatment has the most completed sessions?

## 3. Python layer
`eda_analysis.py` uses Pandas to load the CSV files, check duplicates and missing values,
calculate KPIs, and create two charts. This is exploratory data analysis (EDA).

## 4. Dashboard layer
`dashboard_app.py` loads the same CSV files and presents KPIs and charts. The sidebar
filters the data, and all visuals update based on the selected filters.

## 5. Business decision layer
A data analyst translates the findings into practical recommendations. For example:
- If one area has consistently high patient demand, investigate it as a possible expansion area.
- If cancellation rate is high, investigate reminder timing and booking processes.
- If one treatment is frequently booked, check therapist capacity and scheduling.

These are investigation leads, not automatic decisions. Validate with business owners and
real operational constraints before acting.
