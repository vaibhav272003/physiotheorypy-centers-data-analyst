# Physiotherapy Business Intelligence & Patient Analytics

A portfolio-ready, end-to-end Data Analyst project using **synthetic demonstration data**.
It demonstrates how a physiotherapy business can monitor patient demand, appointments,
revenue, treatment mix, and center performance.

> Privacy note: All records in `data/` are generated sample records. They are not real
> patients and must not be represented as actual FlexifyMe or clinic data.

## Project architecture

1. **CSV files** store the sample data.
2. **SQLite + SQL** joins the tables and answers business questions.
3. **Python (Pandas)** checks data quality and calculates KPIs.
4. **Streamlit + Plotly** displays an interactive dashboard.
5. **Power BI** can use the same CSV files or the SQLite database for a separate BI report.

## Folder structure

- `data/` — patients, appointments, payments, centers, therapists, treatments
- `sql/schema.sql` — database table definitions and relationships
- `sql/business_queries.sql` — business analysis SQL questions
- `src/build_database.py` — loads CSV files into SQLite
- `src/eda_analysis.py` — data quality checks, KPI calculations, and chart exports
- `src/dashboard_app.py` — interactive dashboard
- `docs/` — project workflow and Power BI build guide

## Run on Windows

### 1. Install Python
Install Python 3.10 or newer. During installation, select **Add Python to PATH**.

### 2. Extract the ZIP
Extract `Physiotherapy_Business_Intelligence_Project.zip`.

### 3. Open terminal in the extracted project folder

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

### 4. Build the SQL database

```bash
python src/build_database.py
```

This creates `physiotherapy_analytics.db` in the project folder.

### 5. Run Python analysis

```bash
python src/eda_analysis.py
```

The script prints row counts, missing values, duplicate IDs, completed sessions,
cancellation rate, repeat-patient rate, and paid revenue. It saves charts in `outputs/`.

### 6. Run the interactive dashboard

```bash
streamlit run src/dashboard_app.py
```

A browser tab should open. Use the sidebar to filter by area, appointment status,
and date range.

## How the business metrics work

- **Unique patients:** distinct patient IDs appearing in the filtered appointment data.
- **Appointments:** number of appointment records in the selected filters.
- **Paid revenue:** sum of payment amounts where payment status is `Paid`.
- **Cancellation rate:** cancelled appointments / all filtered appointments × 100.
- **Repeat patients:** patients with at least two completed appointments.
- **Area demand:** distinct patients grouped by area.

Be precise about metric definitions in interviews. For example, appointment count is not
the same as unique patient count, and scheduled appointments should not be counted as
completed sessions.

## SQL practice

Open `sql/business_queries.sql` in DB Browser for SQLite, VS Code with a SQLite extension,
or another SQLite client. Run the queries after building the database.

## Power BI dashboard (manual build)

1. Open Power BI Desktop.
2. Select **Get Data → Text/CSV** and import the six CSV files from `data/`.
3. In Model view, create relationships:
   - `patients[patient_id]` → `appointments[patient_id]`
   - `centers[center_id]` → `appointments[center_id]`
   - `therapists[therapist_id]` → `appointments[therapist_id]`
   - `appointments[appointment_id]` → `payments[appointment_id]`
   - `appointments[appointment_id]` → `treatments[appointment_id]`
4. Create cards for unique patients, appointment count, paid revenue, and cancellation rate.
5. Add a line chart for monthly appointments, bar chart for patient count by area,
   donut chart for appointment status, and bar chart for treatment type.
6. Add slicers for date, area, center, and status.
7. Validate totals against the Python and SQL outputs.

Suggested DAX measures (adjust table/column names if Power BI changes them):

```DAX
Total Appointments = COUNTROWS(appointments)

Unique Patients = DISTINCTCOUNT(appointments[patient_id])

Completed Appointments =
CALCULATE(COUNTROWS(appointments), appointments[status] = "Completed")

Cancelled Appointments =
CALCULATE(COUNTROWS(appointments), appointments[status] = "Cancelled")

Cancellation Rate =
DIVIDE([Cancelled Appointments], [Total Appointments], 0)

Paid Revenue =
CALCULATE(SUM(payments[amount_inr]), payments[payment_status] = "Paid")
```

## Business interpretation: choosing a new center

Do not choose a new location from patient count alone. Rank areas using:
- unique patients and appointment growth,
- repeat visits and paid revenue,
- distance/travel time to existing centers,
- therapist capacity and hiring availability,
- rent, local competition, and expected operating cost.

The sample dataset maps areas to demonstration centers for practicing center analysis.
For a genuine new-center opportunity, add more neighborhoods that do not currently have
a center and collect validated demand and travel-distance information.

## Suggested portfolio presentation

Explain the project in this order:
1. Business problem and objective.
2. Dataset and table relationships.
3. Data quality checks and cleaning decisions.
4. SQL queries and KPI definitions.
5. Python EDA findings.
6. Dashboard walkthrough.
7. Three evidence-based business recommendations.
8. Limitations and next steps.

## Important limitation

This is a learning starter project. It does not connect to a live clinic system, make clinical
recommendations, or predict patient recovery. Do not upload identifiable patient information.
